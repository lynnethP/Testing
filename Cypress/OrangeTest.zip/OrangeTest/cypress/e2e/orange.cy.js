describe("Test Suite", () => {

    beforeEach(() =>{
        cy.visit("https://opensource-demo.orangehrmlive.com/")
    })
    
    it("Pagina de inicio", () => {
        cy.get('.orangehrm-login-branding > img').should("be.visible")    //logo 
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').should("be.visible")    //username 
        cy.get('.orangehrm-copyright-wrapper > :nth-child(1)').contains("OrangeHRM OS 5.4")  //version 
        cy.get('.oxd-button').should("be.visible")    //login
    })

    it.only("Add user", () =>{
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.get('.oxd-button').click()
        cy.get(':nth-child(1) > .oxd-main-menu-item').click()
        cy.get('.orangehrm-header-container > .oxd-button').click()
        cy.get('.oxd-autocomplete-text-input > input').type("Alex Nikol")
        // cy.get('.oxd-autocomplete-text-input > input').type('Paul  Collings').invoke('val').should('contain', 'Paul  Collings');
        // cy.get('.oxd-autocomplete-text-input > input').type("Paul Collings")
        cy.get(':nth-child(4) > .oxd-input-group > :nth-child(2) > .oxd-input').type("natasha12")
        cy.get('.user-password-cell > .oxd-input-group > :nth-child(2) > .oxd-input').type("Hola01**")
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Hola01**")
        cy.get('.oxd-button--secondary').click()
    })

})